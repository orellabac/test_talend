from talend_etl_tooling.talend_analyzer import run_app

if __name__ == "__main__":
    run_app()