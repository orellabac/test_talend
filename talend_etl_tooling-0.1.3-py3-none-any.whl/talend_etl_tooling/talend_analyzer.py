import streamlit as st
import glob
from pathlib import Path
import argparse
import os
import shutil
import tempfile
import zipfile
import pandas as pd
import re
import xml.etree.ElementTree as ET
from snowflake.snowpark import Session
from snowflake.snowpark._internal.utils import is_in_stored_procedure
from snowflake.snowpark.exceptions import SnowparkSQLException
from talend_etl_tooling.utils.snow_connector import get_snowflake_connections, connect_to_snowflake, disconnect_from_snowflake
from talend_etl_tooling.utils.utils import populate_prompts, process_prompt_response, load_conversion_results, generate_code_skeleton, export_migrated_options
from talend_etl_tooling.utils.flow_graph import create_topo_order
from talend_etl_tooling.utils.streamlit_utilities import validate_connection, validate_processor, show_screenshot, display_statistics, generate_sub_graphs

st.set_page_config(layout="wide")
DESTINATION_FOLDER = f"/tmp"
STAGE_NAME = "tmp"

def sidebar():
    disbaled_input = False
    input_folder_changed = False
    if is_in_stored_procedure():
        st.session_state['connected'] = True
        st.session_state['session'] = Session.get_active_session()
        stage_input_location = f"@{STAGE_NAME}/input"
        stage_output_location = f"@{STAGE_NAME}/output"
        
        get_jobs_options = st.radio("Select a Get Job Option", ["Upload .zip file", "Download @TMP Stage"], key='get_jobs_options', horizontal=True)
        if get_jobs_options == "Download @TMP Stage":
            if download_stage_projects(stage_input_location, stage_output_location):
                disbaled_input = True
                input_folder_changed = True
            
        else:
            st.session_state.zip_file = st.file_uploader("Choose .zip file", type=["zip"])
            if st.session_state.zip_file is not None and "zip_basename" in st.session_state and Path(st.session_state.zip_file.name).stem != st.session_state.zip_basename:
                extract_zip_to_temp_folder()
                disbaled_input = True
                input_folder_changed = True

    else:
        if "connections_list" not in st.session_state:
            st.session_state['connections_list'] = get_snowflake_connections()
        
        st.write("Selected Connection: " + st.session_state.get('connection_name', '<none>'))
        connection_name = st.selectbox("Connection", options=st.session_state.connections_list, key='connection_name')

        if connection_name and ('connected' not in st.session_state):
            if st.button("Connect", key='connect'):
                connect_to_snowflake(connection_name)

        if "connected" in st.session_state:
            if st.button("Disconnect", key='disconnect'):
                disconnect_from_snowflake()

    input_folder = st.text_input("Input folder", disabled=disbaled_input, key='input_current', placeholder="Path to Talend XML files")
    if input_folder and not os.path.exists(input_folder):
        st.error(f"Input folder does not exist: {input_folder}")
        st.session_state['input_folder'] = None
        if st.session_state.get('input_folder','') != input_folder:
            input_folder_changed = True
        del st.session_state['input_folder']
    else:
        if st.session_state.get('input_folder','') != input_folder:
            input_folder_changed = True
            st.session_state.talend_files = []
    
    st.session_state['input_folder'] = input_folder
    
    if input_folder_changed:
        if input_folder.strip() == "":
           st.session_state["output_folder"] = ""
        else:
            new_output_folder = os.path.join(os.path.dirname(input_folder), os.path.basename(input_folder).replace(" ","_") + "_etl_output")
            if os.path.exists(input_folder) and not os.path.exists(new_output_folder):
                os.makedirs(new_output_folder)
            st.session_state['output_folder'] = new_output_folder    

    output_folder = st.text_input("Output folder",st.session_state.get('output_folder',''), disabled=disbaled_input, key='output', placeholder="Path to store results")
    if output_folder and not os.path.exists(output_folder):
        st.error(f"Output folder does not exist: {output_folder}")
        st.session_state['output_folder'] = None
        del st.session_state['output_folder']
    
    st.session_state['output_folder'] = output_folder
    
    if is_in_stored_procedure() and validate_connection():
        if st.button("Sync @TMP STAGE"):
            with st.spinner("Processing Sync...", show_time=True):
                session = st.session_state['session']
                project_name = os.path.basename(input_folder)
                session.sql(f"CREATE STAGE IF NOT EXISTS {STAGE_NAME}").collect()
                input_stage = f"@{STAGE_NAME}/input/{project_name}"
                ouput_stage = f"@{STAGE_NAME}/output/{project_name}_etl_output"

                upload_folder_to_stage(st.session_state.input_folder, input_stage, session)
                upload_folder_to_stage(st.session_state.output_folder, ouput_stage, session)

def select_project():
    selected_project = st.selectbox("Projects in @TMP Stage", ["--"] + st.session_state.projects_list, key='projects_box')
    if st.session_state.selected_project_file != selected_project:
        if st.session_state.selected_project_file != None: 
            st.session_state.stage_downloaded = False
        st.session_state.selected_project_file = selected_project
    return selected_project

def extract_zip_to_temp_folder():
    with st.spinner("Extracting .zip...", show_time=True):
        zip_filename = st.session_state.zip_file.name
        st.session_state.zip_basename = Path(zip_filename).stem
        st.session_state.input_folder = f"{DESTINATION_FOLDER}/{st.session_state.zip_basename}"
        st.session_state.input_current = f"{DESTINATION_FOLDER}/{st.session_state.zip_basename}"
            
        if os.path.exists(st.session_state.input_folder):
            shutil.rmtree(st.session_state.input_folder)
        os.makedirs(st.session_state.input_folder)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp_zip:
            tmp_zip.write(st.session_state.zip_file.read())
            tmp_zip_path = tmp_zip.name

        with zipfile.ZipFile(tmp_zip_path, 'r') as zip_ref:
            zip_ref.extractall(DESTINATION_FOLDER)

        st.success(f"ZIP extracted to: {DESTINATION_FOLDER}")

def download_stage_projects(stage_input_location, stage_output_location):
    if "projects_list" not in st.session_state:
        session = st.session_state['session']
        try:
            results = session.sql(f"LIST {stage_input_location}").collect()
        except SnowparkSQLException as e:
            if "does not exist or not authorized" in str(e):
                st.error(f"⛔ Stage '{STAGE_NAME}' does not exist or you are not authorized to access it.")
            else:
                st.error(f"⛔ Error while accessing stage: {e}")
            return False

        projects = set()
        for row in results:
            full_path = row['name']
            path_after_stage = full_path.replace(f"{STAGE_NAME}/", "", 1)
            match = re.match(r"input/([^/]+)/", path_after_stage)
            if match:
                projects.add(match.group(1))

        st.session_state.projects_list = sorted(projects)

    projects_box = select_project()
    if (projects_box != "--" and projects_box) and st.button("Download Stage") and not st.session_state.stage_downloaded:
        with st.spinner("Downloading Stage...", show_time=True):
            session = st.session_state['session']
            destination_input_folder = f"{DESTINATION_FOLDER}/{projects_box}"
            stage_project_input_location = f"{stage_input_location}/{projects_box}"
            destination_output_folder = f"{DESTINATION_FOLDER}/{projects_box}_etl_output"
            stage_project_output_location = f"{stage_output_location}/{projects_box}_etl_output"
            download_stage_to_folder(destination_input_folder, stage_project_input_location, session)
            download_stage_to_folder(destination_output_folder, stage_project_output_location, session)
            st.session_state.stage_downloaded = True
            st.session_state.input_folder = f"{destination_input_folder}"
            st.session_state.input_current = f"{destination_input_folder}"
            st.success(f"Stage downloaded in: {DESTINATION_FOLDER}")
            return True
    return False

def download_stage_to_folder(local_folder, stage_project_location, session):
    os.makedirs(local_folder, exist_ok=True)
    list_sql = f"LIST {stage_project_location}"
    files = session.sql(list_sql).collect()

    for file_info in files:
        stage_full_path = f"@{file_info['name']}"
        relative_path = stage_full_path.replace(stage_project_location + '/', '')
        local_file_path = Path(local_folder) / relative_path
        local_file_path.parent.mkdir(parents=True, exist_ok=True)
        session.file.get(stage_full_path, f"file://{local_file_path.parent}/")

# Helper function to upload folder to stage
def upload_folder_to_stage(local_folder, stage_root, session):
    for dirpath, _, filenames in os.walk(local_folder):
        for filename in filenames:
            full_local_path = os.path.join(dirpath, filename)
            rel_dir = os.path.relpath(dirpath, local_folder)
            stage_subfolder = '' if rel_dir == '.' else rel_dir.replace("\\", "/")
            stage_target_folder = os.path.join(stage_root, stage_subfolder).replace("\\", "/")
            
            session.file.put(
                full_local_path,
                stage_target_folder,
                overwrite=True,
                auto_compress=False
            )

def reset_session_state():
    st.session_state.update({
        "selected_file": None,
        "jobs_list": [],
        "job_name": None,
        "generated_topo_order": False,
        "migrated": pd.DataFrame(),
        "prompt": None,
        "stage_downloaded": False
    })
   
def initialize_session_state():
    if "initialized" not in st.session_state:
        st.session_state.initialized = True
        st.session_state.session = Session.get_active_session()
        st.session_state.screenshot_file = None
        st.session_state.uploaded_file = None
        st.session_state.zip_basename = None
        st.session_state.selected_project_file = None
        st.session_state.initialized = False
        reset_session_state()

def check_streamlit_settings():
    if 'input_folder' not in st.session_state or 'output_folder' not in st.session_state:
        st.error("Please set input and output folders in the sidebar.")
        st.stop()
    
    return argparse.Namespace(
        input=st.session_state['input_folder'],
        output=st.session_state['output_folder'],
        connection_name=st.session_state.get('connection_name', None),
        connected = st.session_state.get('connected', False)
    )

def is_xml_file(file_path):
    """Check if a file is an XML file based on its content."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            first_line = f.readline().strip()
            return first_line.startswith('<?xml')
        return False
    except Exception as e:
        return False
    
def get_talend_files(input_dir):
    """Return list of valid .item XML files under input_dir, including '--' as first option."""
    item_files = glob.glob(str(Path(input_dir) / "**/*.item"), recursive=True)
    item_files += glob.glob(str(Path(input_dir) / "**/*.ITEM"), recursive=True)

    valid_files = []
    for file_path in item_files:
        if is_xml_file(file_path):
            valid_files.append(file_path)

    return ["--"] + valid_files

def select_file():
    selected_file = st.selectbox("Select file", st.session_state.talend_files, key='current_file')
    if selected_file == "--" or not selected_file:
        st.stop()
    if st.session_state.selected_file != selected_file:
        if st.session_state.selected_file != None: 
            reset_session_state()
        st.session_state.selected_file = selected_file
    return selected_file

def find_subgraph_files(base_path):
    folder = base_path.parent
    base_name = base_path.stem
    pattern = re.compile(rf"{re.escape(base_name)}_sub_graph_\d+\.png$")
    matching_files = [p for p in folder.iterdir() if pattern.match(p.name)]
    return sorted(matching_files)

def find_screenshot_file(base_path):
    folder = base_path.parent
    base_name = base_path.stem
    pattern = f"{base_name}.screenshot"

    for p in folder.iterdir():
        if p.name == pattern:
            return p
    return None
        
def content():
    st.title("Talend Acceleration Tool")
    args = check_streamlit_settings()
    initialize_session_state()
    
    st.session_state.outdir = st.session_state.get('output_folder', "")
    st.session_state.input_dir = st.session_state.get('input_folder', "")
    if st.session_state.input_dir == "" or not os.path.exists(st.session_state.input_dir):
        st.error("Please select a valid input folder to analyze.")
        st.stop()
    
    if "talend_files" not in st.session_state or len(st.session_state.talend_files) == 0:
        st.session_state.talend_files = get_talend_files(st.session_state.input_dir)

    outdir = st.session_state.outdir
    st.write(f"Output directory: {outdir}")
    st.write(f"Found {len(st.session_state.talend_files) - 1} Talend files (.item)")
    
    # CHECK if there is some existing outputs
    validate_processor(args, outdir)
    
    selected_file = select_file()
    
    # CHECK if there is a screenshot
    st.session_state.screenshot_file = find_screenshot_file(Path(selected_file))
    if st.session_state.screenshot_file:
        include_screenshot = st.checkbox("Do you want to show the screenshot?", value=False, key='checkbox_screenshot')
        if include_screenshot:
            show_screenshot()

    relative = Path(selected_file).relative_to(Path(st.session_state.input_dir))
    relative_path_no_ext = relative.with_suffix('')
    
    graph_path = Path(outdir) / f"{relative_path_no_ext}.png"
    if graph_path.exists():
        st.image(graph_path)
    else:
        st.error(f"Graph image not found: {graph_path}")
    
    df = pd.read_csv(os.path.join(outdir, "global_instances.csv"))
    file_search = os.path.basename(Path(st.session_state.input_dir)) / relative
    filtered_df = df[df['file'].str.contains(str(file_search), case=False, na=False)].copy()
    
    if not filtered_df.empty:
        checkbox_report = st.checkbox("Do you want to see the report of all the jobs?", value=False, key='checkbox_report')
        if checkbox_report:
            csv_report, report_title = df, "All Jobs Info"
        else:
            csv_report, report_title = filtered_df, "Selected Job Info"
        display_statistics(csv_report, report_title, filtered_df)
    
    tree = ET.parse(selected_file)
    root = tree.getroot()
    job_name = root.attrib.get("name", Path(selected_file).stem)
    
    if not st.session_state.generated_topo_order:
        st.session_state.topo_sort, st.session_state.node_dict, st.session_state.subgraphs_topo = create_topo_order(job_name, tree)
        st.session_state.generated_topo_order = True
    
    code_path = f"{outdir}/transformation/{Path(st.session_state.selected_file).stem}"
    # Migration for main graph
    if st.button("Migrate") and validate_connection():
        with st.spinner("Converting...", show_time=True):
            st.session_state.migrated, st.session_state.prompt = populate_prompts(st.session_state.topo_sort, st.session_state.node_dict)
        with st.spinner("Processing responses..."):
            for i, row in st.session_state.migrated.iterrows():
                prompt = st.session_state.prompt[i][4]
                process_prompt_response(st.session_state.migrated, code_path, row["COMPLETION"], row["LABEL"], row["TYPE"], row["INDEX"], prompt, i)

    sub_graphs = find_subgraph_files(graph_path)
    full_conversion_path = Path(code_path)
    
    if "migrated" not in st.session_state or st.session_state.migrated.empty:
        if full_conversion_path.exists() and any(full_conversion_path.glob("*.py")):
            st.info(f"Loaded previous conversion from cache")
            st.session_state.migrated = load_conversion_results(full_conversion_path)

    # Show migrated results for main graph
    if "migrated" in st.session_state and not st.session_state.migrated.empty:
        migrated = st.session_state.migrated
        for idx, row in migrated.iterrows():
            index, label, type_name, sqlcode, explanation, df_prompt = row["INDEX"], row["LABEL"], row["TYPE"], row["PYTHON_CODE"], row["EXPLANATION"], str(row["PROMPT"])

            with st.expander(f"{index} {label} - ({type_name})"):
                tab_sql_general, tab_explain_general, tab_prompt_general = st.tabs(["Python", "Explanation", "Prompt"])
                with tab_sql_general:
                    st.code(sqlcode, language="python")
                with tab_explain_general:
                    st.markdown(explanation)
                with tab_prompt_general:
                    new_general_prompt = st.text_area("prompt", df_prompt, key=f"{index}_general_prompt", height=min(max(100, int(len(df_prompt) / 2)), 500))
                    if st.button("Rerun", key=f"{index}_general_prompt_rerun_btn"):
                        with st.spinner("Processing Rerun...", show_time=True):
                            completion_row = Session.get_active_session().sql("SELECT SNOWFLAKE.CORTEX.COMPLETE('claude-3-5-sonnet',?)", [new_general_prompt]).first()
                            if completion_row[0]:
                                st.session_state.migrated.loc[st.session_state.migrated['INDEX'] == index, 'COMPLETION'] = completion_row[0]
                                process_prompt_response(st.session_state.migrated, code_path, completion_row[0], label, type_name, index, new_general_prompt, idx)
                                st.rerun()

        st.code(generate_code_skeleton(st.session_state.topo_sort))
        
        file_name = os.path.splitext(os.path.basename(st.session_state.selected_file))[0]
        export_key = "export_as_select_general"
        export_migrated_options(migrated, file_name, export_key)

    # Show sub_graphs results
    if len(sub_graphs) > 0:
        generate_sub_graphs(st.session_state.node_dict, st.session_state.subgraphs_topo, sub_graphs, code_path)

def run_app():
    with st.sidebar:
        sidebar()

    content()

if __name__ == "__main__":
    run_app()
