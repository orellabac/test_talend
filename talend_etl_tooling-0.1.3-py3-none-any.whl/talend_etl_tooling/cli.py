# talend_etl_tooling/cli.py
import sys, os
from streamlit.web import cli as stcli

def main():
    module_dir = os.path.dirname(__file__)
    print("Starting Talend ETL Tooling!")
    app_path = os.path.join(module_dir, "talend_analyzer.py")
    sys.argv = ["streamlit", "run", app_path]
    sys.exit(stcli.main())
