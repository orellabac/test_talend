import toml
import os
import streamlit as st
from snowflake.snowpark import Session

def connect_to_snowflake(connection_name):
    try:
        session = Session.builder.config("connection_name", connection_name).app_name("talend_analyzer").getOrCreate()
        st.session_state['connected'] = True
        st.session_state['session'] = session
        st.success(f"Connected to {connection_name}")
    except Exception as e:
        st.error(f"Error connecting to Snowflake: {e}")


def disconnect_from_snowflake():
    try:
        Session.get_active_session().close()
        st.success("Disconnected from Snowflake")
        st.session_state.pop('connected', None)
        st.session_state.pop('session', None)
        st.rerun()
    except Exception as e:
        st.error(f"Error disconnecting from Snowflake: {e}")


def get_snowflake_connections():
    """
    Searches for Snowflake connection files (~/.snowflake/connections.toml or ~/.snowflake/config.toml)
    and returns a list of connection names found within the 'connections' section.
    """
    home_dir = os.path.expanduser("~")
    snowflake_dir = os.path.join(home_dir, ".snowflake")
    possible_files = ["connections.toml", "config.toml"]

    file_to_parse = next(
        (os.path.join(snowflake_dir, fname) for fname in possible_files if os.path.exists(os.path.join(snowflake_dir, fname))),
        None
    )

    if not file_to_parse:
        print("No Snowflake connection file found at ~/.snowflake/connections.toml or ~/.snowflake/config.toml")
        return []

    try:
        with open(file_to_parse, 'r') as f:
            contents = f.read()

        if "[connections]" in contents:
            config = toml.loads(contents)
            connections = config.get('connections', {})
            return list(connections.keys()) if connections else []
        else:
            connection_names = []
            for line in contents.splitlines():
                stripped = line.strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    section = stripped[1:-1].strip()
                    if section.startswith("connections."):
                        connection_names.append(section.split(".", 1)[1])
            return connection_names
    except Exception as e:
        print(f"Error extracting connection from file {file_to_parse}: {e}")
        return []
