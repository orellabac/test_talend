import xml.etree.ElementTree as ET

def get_format() -> str:
    return """Please respond strictly with a valid JSON object in the following format:
    {
    "python_code": "Your full python code statement here as a single JSON string",
    "explanation": "A concise explanation of how the transformation and field mappings were applied."
    }
    """ 

def _prompt_tmap(node, label, xml_data):
    dependencies = []
    for in_edge in node.get("in_edges", {}):
        dependencies.append(in_edge.get("source").lower())
    xml_data_str = ET.tostring(xml_data, encoding='unicode')
    return f"""
    Convert this Talend tMap node to snowpark python.
    This node will have all its input dataframes from the context dict.
    dependencies: {dependencies}
    You can assume that there is a snowpark session called session. and there is a dict called context which can be used
    to retrieve variables or settings.
    Put the code into a method called {label} that receives session and context
    If this method creates a Dataframe add an instruction like `context['{label.lower()}']=df` before returning
    Be concise and provide the target code:
    {xml_data_str}
    """

def _prompt_tdb2commit(node, label, xml_data):
    xml_data_str = ET.tostring(xml_data, encoding='unicode')
    return f"""
    Convert this Talend tDB2Commit node to  python.
    You can assume that there is a snowpark session called session. and there is a dict called context which can be used
    to retrieve variables or settings in case you needed.
    Put the code into a method called {label} that receives session and context
    Commiting a connection is not needed in snowpark, specially if we assume that
    the data is in snowflake.
    if `sesssion.read.dbapi` was used to connect to external sources then the connection might be closed here
    just add comments as this code block is not needed
    Be concise and provide the target code:
    {xml_data_str}       
    """

def _prompt_tdb2close(node, label, xml_data):
    xml_data_str = ET.tostring(xml_data, encoding='unicode')
    return f"""
    Convert this Talend tDB2Close node to  python.
    You can assume that there is a snowpark session called session. and there is a dict called context which can be used
    to retrieve variables or settings in case you needed.
    Put the code into a method called {label} that receives session and context
    Closing a connection is not needed in snowpark, specially if we assume that
    the data is in snowflake.
    if `sesssion.read.dbapi` was used to connect to external sources then the connection might be closed here
    just add comments as this code block is not needed
    Be concise and provide the target code:
    {xml_data_str}       
    """

def _prompt_tdb2connection(node, label, xml_data):
    xml_data_str = ET.tostring(xml_data, encoding='unicode')
    return f"""
    Convert this Talend tDB2Connection node to  python.
    You can assume that there is a snowpark session called session. and there is a dict called context which can be used
    to retrieve variables or settings in case you needed.
    Put the code into a method called {label} that receives session and context
    Import the appropriate DB2 database module (ibm_db, ibm_db_dbi, or another appropriate driver)
    Extract connection parameters from the Talend XML (host, port, database, username, password, etc.)
    Create a db2 connection object using these parameters
    Add a comment in the code indicating that you are assuming data is in snowflake but that
    `sesssion.read.dbapi` can be used to connect to external sources
    Be concise and provide the target code:
    {xml_data_str}       
    """

def _prompt_tsnowflakeinput(node, label, xml_data):
    props = xml_data.find(".//elementParameter[@name='PROPERTIES']").get('value').replace("&quot;",'"')
    return f"""
    Convert this Talend tSnowflakeInput node to snowpark python.
    You can assume that there is a snowpark session called session. and there is a dict called context which can be used
    to retrieve variables or settings.
    Put the code into a method called {label} that receives session and context
    If this method creates a Dataframe add an instruction like `context['{label.lower()}']=df` before returning
    Be concise and provide the target code:
    {props}

    {label.lower()}
    """

def _prompt_default(node, node_type, label, xml_data):
    xml_data_str = ET.tostring(xml_data, encoding='unicode')
    return f"""
    Convert this Talend {node_type} node to snowpark python.
    You can assume that there is a snowpark session called session. and there is a dict called context which can be used
    to retrieve variables or settings.
    Put the code into a method called {label} that receives session and context
    Be concise and provide the target code:
    {xml_data_str}
    """

def generate_prompt(node):
    prompt = get_prompt(node)
    return f"{prompt}\n{get_format()}"

def get_prompt(node):
    node_type = node.get("type")
    xml_data = node.get("xml_data")
    label = (node.get("unique_name") or "").lower()

    if node_type == "tMap":
        return _prompt_tmap(node, label, xml_data)

    if node_type == "tDB2Commit":
        return _prompt_tdb2commit(node, label, xml_data)

    if node_type == "tDB2Close":
        return _prompt_tdb2close(node, label, xml_data)

    if node_type == "tDB2Connection":
        return _prompt_tdb2connection(node, label, xml_data)

    if node_type == "tSnowflakeInput":
        return _prompt_tsnowflakeinput(node, label, xml_data)

    return _prompt_default(node, node_type, label, xml_data)
