import json
import os
from pathlib import Path
import re
import pandas as pd
import streamlit as st
import csv
import logging
from utils.talend_steps_prompts import generate_prompt
from utils.export import export_as_notebook, export_as_python_script, format_notebook_for_download

PROMPTS_TABLE = "prompts"
CORTEX_MODEL = "claude-3-5-sonnet"

def generate_code_skeleton(topo_order):
    """
    Generates a Python code skeleton for Snowflake Snowpark components.
    """
    lines = [
        "# Generated Python code skeleton",
        "from snowflake.snowpark import Session",
        "from snowflake.snowpark.functions import col, lit",
        "",
        "",
    ]

    # Function definitions for each component
    for comp_id in topo_order:
        lines.append(f"def {comp_id.lower()}(session, context):")
        lines.append(f"    # TODO: Implement logic for {comp_id}")
        lines.append("    pass\n")

    # Main execution flow
    lines.append("def main():")
    lines.append("    # Initialize context")
    lines.append("    context = {}  # TODO: Replace with actual initial data")
    lines.append("    session = Session.builder.configs({}).create()  # TODO: Configure session")

    for comp_id in topo_order:
        lines.append(f"    {comp_id.lower()}(session, context)")

    lines.append("")
    lines.append("if __name__ == '__main__':")
    lines.append("    main()")

    return "\n".join(lines)


def write_prompts_and_query(prompt_info):
    """
    Writes prompt_info to Snowflake and queries Cortex completions.
    Returns a Pandas DataFrame with completions and the prompt info list.
    """
    session = st.session_state["session"]
    df = session.create_dataframe(prompt_info, schema=["index", "id", "label", "type", "prompt"])
    df.write.mode("overwrite").save_as_table(PROMPTS_TABLE)

    query = f"""
        SELECT 
            INDEX, ID, LABEL, TYPE,
            SNOWFLAKE.CORTEX.COMPLETE('{CORTEX_MODEL}', PROMPT) AS COMPLETION, PROMPT
        FROM {PROMPTS_TABLE}
    """
    result_df = session.sql(query).to_pandas()
    result_df['PYTHON_CODE'] = None
    result_df['EXPLANATION'] = None
    return result_df, prompt_info

def populate_prompts(topo_sort, nodes_dict):
    """
    Generates prompts using the node metadata and calls Cortex for completions.
    Returns the resulting DataFrame and prompt_info list.
    """
    prompt_info = [
        [idx, node_id, node.get("unique_name", node_id), node.get("type", ""), generate_prompt(node)]
        for idx, node_id in enumerate(topo_sort)
        for node in [nodes_dict.get(node_id, {})]
    ]
    return write_prompts_and_query(prompt_info)

def write_csv(file_path, data, mode="w") -> None:
    """Write list of dictionaries to a CSV file."""
    if not data:
        logging.info(f"No data to write to {file_path}")
        return

    file_exists = file_path.exists()
    try:
        with open(file_path, mode=mode, newline="") as file:
            fieldnames = data[0].keys()
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            if not file_exists or mode == "w":
                writer.writeheader()
            writer.writerows(data)

        logging.info(f"Component info written to: {file_path}")
    except Exception as e:
        logging.error(f"Failed to write CSV file {file_path}: {e}")
        raise

def process_prompt_response(df, outdir, completion, name, type_jb, index, prompt, i):
    try:
        prompt_text = prompt[4] if isinstance(prompt, (list, tuple)) and len(prompt) > 4 else prompt
        response_json = json.loads(completion)
        python_code = response_json["python_code"]
        explanation = response_json["explanation"]
        df.at[i, "PYTHON_CODE"] = python_code
        df.at[i, "EXPLANATION"] = explanation

        #if int(index) in df.index:
        #    df.loc[df['INDEX'] == index, 'PROMPT'] = prompt_text
        
        os.makedirs(outdir, exist_ok=True)
        base_filename = Path(outdir) / f"{index:00}_{type_jb}_{name}"
        base_filename.with_suffix(".py").write_text(python_code)
        base_filename.with_suffix(".txt").write_text(explanation)
        base_filename.with_suffix(".prompt.txt").write_text(prompt_text)

        return completion
    except Exception as e:
        st.error(f"Error processing response for {index} {name}: {e}")

def load_conversion_results(output_path):
    """
    Loads conversion result files from the given output_path and returns a sorted DataFrame.
    Expects files named as: <index>_<name>_<type>.prompt.txt, .py, or .txt
    """
    entries = {}

    for file in output_path.glob("*"):
        match = re.match(r"(\d+)_(.+?)_(.+?)(\.prompt\.txt|\.txt|\.py)$", file.name)
        if not match:
            continue
        index, name, type_jb, ext = match.groups()
        key = (index, name)
        if key not in entries:
            entries[key] = {"INDEX": index, "ID": index, "LABEL": name, "TYPE": type_jb, "COMPLETION": None, "PYTHON_CODE": None, "EXPLANATION": None}

        content = file.read_text(encoding="utf-8").strip()

        if ext == ".prompt.txt":
            entries[key]["PROMPT"] = content
        elif ext == ".py":
            entries[key]["PYTHON_CODE"] = content
        elif ext == ".txt":
            if not file.name.endswith(".prompt.txt"):
                entries[key]["EXPLANATION"] = content

    # Convert to DataFrame
    df = pd.DataFrame(entries.values())

    df = pd.DataFrame(entries.values()).sort_values("INDEX").reset_index(drop=True)
    return df

def export_migrated_options(migrated, file_name, export_key):
    col1, col2 = st.columns([2, 2])
    with col1:
        st.subheader("Export Options")
        export_format = st.selectbox(
                "Select the export format:",
                options=["Select...", "Python Script", "Notebook"],
                index=0,
                key=f'{export_key}'
            )

        st.session_state['export_as_option'] = export_format.lower()

        if export_format == "Python Script":
            output_file = f"{file_name}.py"
            sql_script = export_as_python_script(migrated)
            st.download_button(
                    label=f"📥 Download Python script: {output_file}",
                    data=sql_script,
                    file_name=output_file,
                    mime="text/x-python"
                )

        elif export_format == "Notebook":
            output_file = f"{file_name}.ipynb"
            notebook = export_as_notebook(migrated)
            notebook_json = format_notebook_for_download(notebook)
            st.download_button(
                    label=f"📥 Download Notebook: {output_file}",
                    data=notebook_json,
                    file_name=output_file,
                    mime="application/json"
                )
