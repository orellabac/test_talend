from pathlib import Path
import streamlit as st
import sys, os
import subprocess
import time
import plotly.express as px
import xml.etree.ElementTree as ET
import io
import base64
from snowflake.snowpark import Session
from PIL import Image
from utils.utils import generate_code_skeleton, populate_prompts, process_prompt_response, load_conversion_results, export_migrated_options

def validate_connection():
    if not st.session_state.get('connected'):
        st.error("Please connect to a Snowflake instance in the sidebar.")
        return False
    
    return True

def validate_processor(args, outdir):
    if not os.path.exists(os.path.join(outdir, "global_instances.csv")):
        st.error(f"No output files found in {outdir}. Please run the CLI tool first to generate the cache files.")
        if st.button("Run CLI Tool"):
            module_dir = os.path.dirname(os.path.dirname(__file__))
            app_path = os.path.join(module_dir, "talend_processor.py")
            with st.spinner("Running CLI tool...", show_time=True):
                subprocess.run([sys.executable, app_path, "--input", args.input, "--output", outdir])
            st.success("CLI tool executed successfully...")
            time.sleep(2)
            st.rerun()
        st.stop()
    else:
        if st.button("Re-Run CLI Tool"):
            module_dir = os.path.dirname(os.path.dirname(__file__))
            app_path = os.path.join(module_dir, "talend_processor.py")
            with st.spinner("Running CLI tool...", show_time=True):
                subprocess.run([sys.executable, app_path, "--input", args.input, "--output", outdir])

def show_screenshot():
    try:
        content = st.session_state.screenshot_file.read_text("utf-8")
        tree = ET.ElementTree(ET.fromstring(content))
        root = tree.getroot()
    except Exception as e:
        st.error(f"Failed to parse XML: {e}")
        return

    ns = {
        'xmi': 'http://www.omg.org/XMI',
        'talendfile': 'platform:/resource/org.talend.model/model/TalendFile.xsd'
    }

    def display_image_from_base64(image64data):
        try:
            image_bytes = base64.b64decode(image64data)
            image = Image.open(io.BytesIO(image_bytes))
            st.image(image, use_container_width=True)
        except Exception as e:
            st.warning(f"Could not display image: {e}")

    screenshots = root.findall('.//talendfile:ScreenshotsMap', ns)
    if screenshots:
        st.write(f"{len(screenshots)} screenshot(s) found")
        for screenshot in screenshots:
            image64data = screenshot.attrib.get("value")
            if image64data:
                display_image_from_base64(image64data)
            else:
                st.warning("Screenshot element missing 'value' attribute.")
    elif root.tag == "{platform:/resource/org.talend.model/model/TalendFile.xsd}ScreenshotsMap":
        image64data = root.attrib.get("value")
        if image64data:
            display_image_from_base64(image64data)
        else:
            st.warning("Root element missing 'value' attribute.")
    else:
        st.warning("No screenshots found in the uploaded file.")

def display_statistics(filtered_df):
    with st.expander("Job Info", expanded=False):
        st.dataframe(filtered_df)

    result = filtered_df["component_type"].value_counts().reset_index()
    result.columns = ["component_type", "count"]

    fig = px.bar(
            result,
            x='component_type',
            y='count',
            title='Component Distribution',
            color='count',
            color_continuous_scale='Viridis'
        )
    fig.update_layout(
            title_x=0.5,
            xaxis_title="Component Type",
            yaxis_title="Number of Occurrences",
            hoverlabel=dict(bgcolor="white"),
            font=dict(size=12)
        )
    st.plotly_chart(fig)

def generate_sub_graphs(node_dict, subgraphs_topo, sub_graphs, outdir):
    st.warning("There are several flows")
    for id_sg, sub_graph in enumerate(sub_graphs):
        st.subheader(f"SubGraph {id_sg}")
        st.image(sub_graph)
        migrated_key = f"migrated_subgraph_{id_sg}"
        prompt_key = f"migrated_prompt_{id_sg}"
        sub_topo_sort = subgraphs_topo[id_sg]
        if st.button("Migrate", key=f"btn_mig_{migrated_key}") and validate_connection():
            with st.spinner("Converting...", show_time=True):
                st.session_state[migrated_key], st.session_state[prompt_key] = populate_prompts(sub_topo_sort, node_dict)
            with st.spinner("Processing responses..."):
                for id_, row in st.session_state[migrated_key].iterrows():
                    prompt = st.session_state[prompt_key][id_]
                    process_prompt_response(st.session_state[migrated_key], f"{outdir}/subgraph_{id_sg}", row["COMPLETION"], row["LABEL"], row["TYPE"], row["INDEX"], prompt, id_)

        full_conversion_path = Path(f"{outdir}/subgraph_{id_sg}")
        if migrated_key not in st.session_state or st.session_state[migrated_key].empty:
            if full_conversion_path.exists() and any(full_conversion_path.glob("*.py")):
                st.info(f"Loaded previous conversion from cache")
                st.session_state[migrated_key] = load_conversion_results(full_conversion_path)

        if migrated_key in st.session_state:
            migrated_sub = st.session_state[migrated_key]
            with st.expander(f"SubGraph {id_sg}", expanded=True):
                tab_python, tab_prompt = st.tabs(["Python", "Prompt"])

                with tab_python:
                    for _, row in migrated_sub.iterrows():
                        index, label, type_name, sqlcode, explanation, df_graph_prompt = row["INDEX"], row["LABEL"], row["TYPE"], row["PYTHON_CODE"], row["EXPLANATION"], str(row["PROMPT"])
                        with st.expander(f"Subgraph {id_sg} {label} - ({type_name})"):
                            st.code(sqlcode, language="python")
                            st.markdown(explanation)
                    st.code(generate_code_skeleton(sub_topo_sort))
            
                    with tab_prompt:
                        for id_, row in migrated_sub.iterrows():
                            index, label, type_name, sqlcode, explanation, df_graph_prompt = row["INDEX"], row["LABEL"], row["TYPE"], row["PYTHON_CODE"], row["EXPLANATION"], str(row["PROMPT"])
                            new_prompt = st.text_area(f"Prompt: Node {index} ({label} → {type_name})", df_graph_prompt, key=f"subgraph_{id_sg}_prompt_node_{index}", height=min(max(100, int(len(df_graph_prompt) / 2)), 500))
                            if st.button("Rerun", key=f"subgraph_{id_sg}_prompt_node_{index}_rerun_btn"):
                                with st.spinner("Processing Rerun...", show_time=True):
                                    completion_row = Session.get_active_session().sql("SELECT SNOWFLAKE.CORTEX.COMPLETE('claude-3-5-sonnet',?)", [new_prompt]).first()
                                    if completion_row[0]:
                                        st.session_state[migrated_key].loc[st.session_state[migrated_key]['INDEX'] == index, 'COMPLETION'] = completion_row[0]
                                        process_prompt_response(st.session_state[migrated_key], f"{outdir}/subgraph_{id_sg}", completion_row[0], type_name, label, index, new_prompt, id_)
                                        st.rerun()

                file_name = "_".join(full_conversion_path.parts[-2:])
                export_key = f'export_as_select_{id_sg}'
                export_migrated_options(migrated_sub, file_name, export_key)
