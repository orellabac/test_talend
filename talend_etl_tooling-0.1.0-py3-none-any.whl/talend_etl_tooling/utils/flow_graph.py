import html
import re
import streamlit as st
import graphviz
import networkx as nx
from collections import defaultdict

def create_topo_order(job_name, tree):
    """Create a Graphviz diagram and related data from Talend job files."""
    job_name, components, connections = parse_talend_job(job_name, tree)
    topo_sort = topological_sort(components)
    subgraphs = extract_subgraphs(components)
    subgraphs_topo = {i: topological_sort(sub) for i, sub in enumerate(subgraphs)}
    return topo_sort, components, subgraphs_topo

def create_dependency_graph(job_name, tree):
    """Create a Graphviz diagram and related data from Talend job files."""
    job_name, components, connections = parse_talend_job(job_name, tree)
    graph = build_graphviz_graph(components)
    subgraphs = extract_subgraphs(components)
    return graph, subgraphs

def parse_talend_job(job_name, tree):
    """Parse a Talend job XML file and extract component connections."""
    root = tree.getroot()
    components = {}
    connections = []

    # Extract components
    for component in root.findall(".//node"):
        component_name = component.get('componentName')
        if component_name:
            unique_name = component.find(".//elementParameter[@name='UNIQUE_NAME']").get('value')
            try:
                label = component.find(".//elementParameter[@name='LABEL']").get('value')
            except:
                label = unique_name

            components[unique_name] = {
                "label": label,
                "unique_name": unique_name,
                "type": component_name,
                "out_edges": [],
                "in_edges": [],
                "xml_data": component
            }

    # Extract connections
    for connection in root.findall(".//connection"):
        source = connection.get('source')
        target = connection.get('target')
        name = connection.get('connectorName')
        label = connection.get('label')
        edge_info = {"source": source, "target": target, "name": name, "label": label}
        connections.append(edge_info)
        if source in components:
            components[source]["out_edges"].append(edge_info)
        else:
            st.error(f"Source component not found: {source}")
        if target in components:
            components[target]["in_edges"].append(edge_info)

    return job_name, components, connections

def build_graphviz_graph(components):
    """Build a Graphviz Digraph from components."""
    graph = graphviz.Digraph(
        comment='Talend Job Dependencies',
        edge_attr={"color": "#6a9c3e", "arrowtail": "box", "dir": "both"}
    )
    graph.attr('node', shape='box')
    graph.attr('graph', rankdir='LR')
    
    for comp_id, comp_data in components.items():
        label = generate_instance_label(comp_data)
        graph.node(comp_id, label, shape='plaintext', style='rounded', peripheries='1')
    
    added_edges = set()
    
    for comp_id, comp_data in components.items():
        for edge_info in comp_data.get("out_edges", []):
            target = edge_info.get("target")
            label_edge = edge_info.get("label")
            key = (comp_id, target)
            if key not in added_edges:
                graph.edge(comp_id, target, label=label_edge)
                added_edges.add(key)
    return graph

def generate_instance_label(instance):
    """Create a valid HTML-like Graphviz label for an instance node."""
    name = instance.get("unique_name", "Unnamed")
    label = html.unescape(name)
    label = re.sub(r'<\/?[^>]+>', '', label)
    label = re.sub(r'[^a-zA-Z0-9_]', '_', label)
    t_type = instance.get("type", "Unknown")
    is_special = t_type in {'tPrejob', 'tPostjob'}
    job_color = "#E1DCB4" if is_special else "#E6F0F6"
    job_color_tittle = "#E66400" if is_special else "#62839A"

    return f'''<
<table border="0" cellborder="1" cellspacing="0" cellpadding="4" bgcolor="{job_color}">
  <tr><td bgcolor="{job_color_tittle}"><b>{t_type}</b></td></tr>
  <tr><td>{label}</td></tr>
</table>
>'''

def topological_sort(components):
    """Return a topological sort of the components, or None if cyclic."""
    graph = defaultdict(list)
    for node_id, node_data in components.items():
        for edge in node_data.get("out_edges", []):
            graph[node_id].append(edge["target"])
    visited, temp_mark, result = set(), set(), []

    def dfs(node):
        if node in temp_mark:
            raise ValueError("Graph has at least one cycle")
        if node in visited:
            return
        temp_mark.add(node)
        for neighbor in graph[node]:
            dfs(neighbor)
        temp_mark.remove(node)
        visited.add(node)
        result.insert(0, node)

    try:
        for node in components:
            if node not in visited:
                dfs(node)
    except ValueError as e:
        st.error(str(e))
        return None
    return result

def extract_subgraphs(components):
    """Extract weakly connected subgraphs from components."""
    G = nx.DiGraph()
    G.add_nodes_from(components)
    for comp_id, comp_data in components.items():
        for edge_info in comp_data.get("out_edges", []):
            target = edge_info.get("target")
            if target:
                G.add_edge(comp_id, target)
    subgraphs = []
    for nodes in nx.weakly_connected_components(G):
        subgraphs.append({node: components[node] for node in nodes if node in components})
    return subgraphs

def build_graphviz_subgraph(subgraph, i):
    """Build a Graphviz Digraph for a subgraph."""
    graph = graphviz.Digraph(
        comment=f'Talend Job Dependencies - Subgraph {i+1}',
        edge_attr={"color": "#6a9c3e", "arrowtail": "box", "dir": "both"}
    )
    graph.attr('node', shape='box')
    graph.attr('graph', rankdir='LR')

    for comp_id, comp_data in subgraph.items():
        label = generate_instance_label(comp_data)
        graph.node(comp_id, label, shape='plaintext', style='rounded', peripheries='1')
    added_edges = set()
    for comp_id, comp_data in subgraph.items():
        for edge_info in comp_data.get("out_edges", []):
            target = edge_info.get("target")
            label_edge = edge_info.get("label")
            key = (comp_id, target)
            if target in subgraph and key not in added_edges:
                graph.edge(comp_id, target, label=label_edge)
                added_edges.add(key)
    return graph
