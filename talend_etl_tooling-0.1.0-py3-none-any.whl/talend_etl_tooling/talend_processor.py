import argparse
import glob
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from lxml import etree
import logging
from utils.flow_graph import create_dependency_graph, build_graphviz_subgraph
from utils.utils import write_csv

RE_XML_ENCODING = re.compile(r'^(<\?xml[^>]+).*\s+encoding\s*=\s*["\'][^"\']*["\'](\s*\?>|)', re.U)

def parse_args():
    parser = argparse.ArgumentParser(description="Process Informatica PowerCenter exported workflows.")
    parser.add_argument('--input', type=str, required=True, help='Path to exported XML files.')
    parser.add_argument('--output', type=str, required=True, help='Path to store results.')
    return parser.parse_args()

def setup_logging(output_dir):
    log_file = Path(output_dir) / "_talend_processor.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file, mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def is_xml_file(file_path):
    """Check if a file is an XML file based on its content."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            first_line = f.readline().strip()
            return first_line.startswith('<?xml')
    except UnicodeDecodeError:
        logging.warning(f"File is not valid UTF-8 or is binary: {file_path}")
        return False
    except Exception as e:
        logging.error(f"Unable to read file {file_path} for XML validation: {e}")
        return False

def collect_talend_files(input_path):
    """Collect all .item files (case-insensitive) recursively from input_path."""
    path = Path(input_path)
    pattern = str(path / "**/*.item")
    files = glob.glob(pattern, recursive=True)
    files += glob.glob(pattern.upper(), recursive=True)
    return [Path(f) for f in files]

def get_relative_output_base(talend_file, input_dir, output_dir):
    """Compute output base path relative to input_dir."""
    talend_file_path = Path(talend_file).resolve()
    input_dir = Path(input_dir).resolve()
    try:
        rel_path = talend_file_path.relative_to(input_dir).parent
    except ValueError:
        rel_path = Path()
    output_base = output_dir / rel_path / talend_file_path.stem
    output_base.parent.mkdir(parents=True, exist_ok=True)
    return output_base

def render_graph(graph, output_base):
    """Render graph to SVG and PNG."""
    svg_content = graph.pipe(format='svg').decode('utf-8')
    graph.render(str(output_base), format='png', view=False)
    return svg_content
    
def process_file(talend_file, output_dir, input_dir, global_instances_data):
    """
    Processes a Talend .item XML file by parsing its contents, generating dependency graphs, rendering visualizations,
    and extracting component information.
    """
    logging.info(f"Processing file: {talend_file}")
    if not is_xml_file(talend_file):
        logging.warning(f"Skipping non-XML file: {talend_file}")
        return

    try:
        tree = ET.parse(talend_file)
        root = tree.getroot()
    except Exception as e:
        logging.error(f"Failed to parse .item XML: {e}")
        return

    try:
        job_name = root.attrib.get("name", Path(talend_file).stem)
        graph, subgraphs = create_dependency_graph(job_name, tree)
    except Exception as e:
        logging.error(f"Error creating dependency graph for {talend_file}: {e}")
        return

    output_base = get_relative_output_base(talend_file, input_dir, output_dir)

    try:
        render_graph(graph, output_base)
    except Exception as e:
        logging.error(f"Error rendering graph for {talend_file}: {e}")

    if len(subgraphs) > 1:
        for i, s in enumerate(subgraphs):
            logging.info(f"Processing sub_graph: {i}")
            try:
                sub_graph = build_graphviz_subgraph(s, i)
                output_base_sub = output_base.with_name(f"{output_base.name}_sub_graph_{i}")
                render_graph(sub_graph, output_base_sub)
            except Exception as e:
                logging.error(f"Error rendering subgraph {i} for {talend_file}: {e}")
                
    extract_component_info(root, talend_file, global_instances_data)

def extract_component_info(root, talend_file, global_instances_data):
    for component in root.findall('.//node'):
        component_name = component.get('componentName')
        if component_name:
            unique_name_elem = component.find(".//elementParameter[@name='UNIQUE_NAME']")
            unique_name = unique_name_elem.get('value') if unique_name_elem is not None else None
            instance_data = {
                'file': str(talend_file),
                'component_type': component_name,
                'unique_name': unique_name,
            }
            global_instances_data.append(instance_data)

def main():
    args = parse_args()
    input_dir = Path(args.input)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_logging(output_dir)
    talend_files = collect_talend_files(input_dir)
    global_instances_data = []

    for file_path in talend_files:
        try:
            process_file(file_path, output_dir, input_dir, global_instances_data)
        except Exception as e:
            logging.error(f"Error processing file {file_path}: {e}")

    write_csv(output_dir / "global_instances.csv", global_instances_data)
    logging.info("Process Completed")

if __name__ == "__main__":
    main()
