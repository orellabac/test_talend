import streamlit as st
import glob
from pathlib import Path
import argparse
import os
import pandas as pd
import re
import xml.etree.ElementTree as ET
from snowflake.snowpark import Session
from snowflake.snowpark._internal.utils import is_in_stored_procedure
from utils.snow_connector import get_snowflake_connections, connect_to_snowflake, disconnect_from_snowflake
from utils.utils import populate_prompts, process_prompt_response, load_conversion_results, generate_code_skeleton, export_migrated_options
from utils.flow_graph import create_topo_order
from utils.streamlit_utilities import validate_connection, validate_processor, show_screenshot, display_statistics, generate_sub_graphs

st.set_page_config(layout="wide")

def sidebar():
    if is_in_stored_procedure():
        st.session_state['connected'] = True
        st.session_state['session'] = Session.get_active_session()
    else:
        if "connections_list" not in st.session_state:
            st.session_state['connections_list'] = get_snowflake_connections()
        
        st.write("Selected Connection: " + st.session_state.get('connection_name', '<none>'))
        connection_name = st.selectbox("Connection", options=st.session_state.connections_list, key='connection_name')

        if connection_name and ('connected' not in st.session_state):
            if st.button("Connect", key='connect'):
                connect_to_snowflake(connection_name)

        if "connected" in st.session_state:
            if st.button("Disconnect", key='disconnect'):
                disconnect_from_snowflake()

    input_folder = st.text_input("Input folder", st.session_state.get("input_folder",""), key='input', placeholder="Path to Talend XML files")
    input_folder_changed = False
    if input_folder and not os.path.exists(input_folder):
        st.error(f"Input folder does not exist: {input_folder}")
        st.session_state['input_folder'] = None
        if st.session_state.get('input_folder','') != input_folder:
            input_folder_changed = True
        del st.session_state['input_folder']
    else:
        if st.session_state.get('input_folder','') != input_folder:
            input_folder_changed = True
            st.session_state.talend_files = []
    
    st.session_state['input_folder'] = input_folder
    
    if input_folder_changed:
        if input_folder.strip() == "":
           st.session_state["output_folder"] = ""
        else: 
            new_output_folder = os.path.join(os.path.dirname(input_folder), os.path.basename(input_folder).replace(" ","_") + "_etl_output")
            if os.path.exists(input_folder) and not os.path.exists(new_output_folder):
                os.makedirs(new_output_folder)
            st.session_state['output_folder'] = new_output_folder    

    output_folder   = st.text_input("Output folder",st.session_state.get('output_folder',''), key='output', placeholder="Path to store results")
    if output_folder and not os.path.exists(output_folder):
        st.error(f"Output folder does not exist: {output_folder}")
        st.session_state['output_folder'] = None
        del st.session_state['output_folder']
    
    st.session_state['output_folder'] = output_folder

def reset_session_state():
    st.session_state.update({
        "selected_file": None,
        "jobs_list": [],
        "job_name": None,
        "generated_topo_order": False,
        "migrated": pd.DataFrame(),
        "prompt": None,
        "checkbox_screenshot": False
    })
   
def initialize_session_state():
    if "initialized" not in st.session_state:
        st.session_state.initialized = True
        st.session_state.session = Session.get_active_session()
        st.session_state.screenshot_file = None
        st.session_state.uploaded_file = None
        reset_session_state()

def check_streamlit_settings():
    if 'input_folder' not in st.session_state or 'output_folder' not in st.session_state:
        st.error("Please set input and output folders in the sidebar.")
        st.stop()
    
    return argparse.Namespace(
        input=st.session_state['input_folder'],
        output=st.session_state['output_folder'],
        connection_name=st.session_state.get('connection_name', None),
        connected = st.session_state.get('connected', False)
    )

def is_xml_file(file_path):
    """Check if a file is an XML file based on its content."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            first_line = f.readline().strip()
            return first_line.startswith('<?xml')
        return False
    except Exception as e:
        return False
    
def get_talend_files(input_dir):
    """Return list of valid .item XML files under input_dir, including '--' as first option."""
    item_files = glob.glob(str(Path(input_dir) / "**/*.item"), recursive=True)
    item_files += glob.glob(str(Path(input_dir) / "**/*.ITEM"), recursive=True)

    valid_files = []
    for file_path in item_files:
        if is_xml_file(file_path):
            valid_files.append(file_path)

    return ["--"] + valid_files

def select_file():
    selected_file = st.selectbox("Select file", st.session_state.talend_files, key='current_file')
    if selected_file == "--" or not selected_file:
        st.stop()
    if st.session_state.selected_file != selected_file:
        if st.session_state.selected_file != None: 
            reset_session_state()
        st.session_state.selected_file = selected_file
    return selected_file

def find_subgraph_files(base_path):
    folder = base_path.parent
    base_name = base_path.stem
    pattern = re.compile(rf"{re.escape(base_name)}_sub_graph_\d+\.png$")
    matching_files = [p for p in folder.iterdir() if pattern.match(p.name)]
    return sorted(matching_files)

def find_screenshot_file(base_path):
    folder = base_path.parent
    base_name = base_path.stem
    pattern = f"{base_name}.screenshot"

    for p in folder.iterdir():
        if p.name == pattern:
            return p
    return None
        
def content():
    st.title("Talend Acceleration Tool")
    args = check_streamlit_settings()
    initialize_session_state()
    
    st.session_state.outdir = st.session_state.get('output_folder', "")
    st.session_state.input_dir = st.session_state.get('input_folder', "")
    if st.session_state.input_dir == "":
        st.error("Please select a input folder to analyze.")
        st.stop()
    
    if len(st.session_state.talend_files) == 0:
        st.session_state.talend_files = get_talend_files(st.session_state.input_dir)

    outdir = st.session_state.outdir
    st.write(f"Output directory: {outdir}")
    st.write(f"Found {len(st.session_state.talend_files) - 1} Talend files (.item)")
    
    # CHECK if there is some existing outputs
    validate_processor(args, outdir)
    
    selected_file = select_file()
    
     # CHECK if there is a screenshot
    st.session_state.screenshot_file = find_screenshot_file(Path(selected_file))
    if st.session_state.screenshot_file:
        include_screenshot = st.checkbox("Do you want to show the screenshot?", value=False, key='checkbox_screenshot')
        if include_screenshot:
            show_screenshot()

    relative = Path(selected_file).relative_to(Path(st.session_state.input_dir))
    relative_path_no_ext = relative.with_suffix('')
    
    graph_path = Path(outdir) / f"{relative_path_no_ext}.png"
    if graph_path.exists():
        st.image(graph_path)
    else:
        st.error(f"Graph image not found: {graph_path}")
    
    df = pd.read_csv(os.path.join(outdir, "global_instances.csv"))
    filtered_df = df[df['file'] == selected_file].copy()
    
    if not filtered_df.empty:
        display_statistics(filtered_df)
    
    tree = ET.parse(selected_file)
    root = tree.getroot()
    job_name = root.attrib.get("name", Path(selected_file).stem)
    
    if not st.session_state.generated_topo_order:
        st.session_state.topo_sort, st.session_state.node_dict, st.session_state.subgraphs_topo = create_topo_order(job_name, tree)
        st.session_state.generated_topo_order = True
    
    code_path = f"{outdir}/transformation/{Path(st.session_state.selected_file).stem}"
    # Migration for main graph
    if st.button("Migrate") and validate_connection():
        with st.spinner("Converting...", show_time=True):
            st.session_state.migrated, st.session_state.prompt = populate_prompts(st.session_state.topo_sort, st.session_state.node_dict)
        with st.spinner("Processing responses..."):
            for i, row in st.session_state.migrated.iterrows():
                prompt = st.session_state.prompt[i][4]
                process_prompt_response(st.session_state.migrated, code_path, row["COMPLETION"], row["LABEL"], row["TYPE"], row["INDEX"], prompt, i)

    sub_graphs = find_subgraph_files(graph_path)
    full_conversion_path = Path(code_path)
    
    if "migrated" not in st.session_state or st.session_state.migrated.empty:
        if full_conversion_path.exists() and any(full_conversion_path.glob("*.py")):
            st.info(f"Loaded previous conversion from cache")
            st.session_state.migrated = load_conversion_results(full_conversion_path)

    # Show migrated results for main graph
    if "migrated" in st.session_state and not st.session_state.migrated.empty:
        migrated = st.session_state.migrated
        for idx, row in migrated.iterrows():
            index, label, type_name, sqlcode, explanation, df_prompt = row["INDEX"], row["LABEL"], row["TYPE"], row["PYTHON_CODE"], row["EXPLANATION"], str(row["PROMPT"])

            with st.expander(f"{index} {label} - ({type_name})"):
                tab_sql_general, tab_explain_general, tab_prompt_general = st.tabs(["Python", "Explanation", "Prompt"])
                with tab_sql_general:
                    st.code(sqlcode, language="python")
                with tab_explain_general:
                    st.markdown(explanation)
                with tab_prompt_general:
                    new_general_prompt = st.text_area("prompt", df_prompt, key=f"{index}_general_prompt", height=min(max(100, int(len(df_prompt) / 2)), 500))
                    if st.button("Rerun", key=f"{index}_general_prompt_rerun_btn"):
                        with st.spinner("Processing Rerun...", show_time=True):
                            completion_row = Session.get_active_session().sql("SELECT SNOWFLAKE.CORTEX.COMPLETE('claude-3-5-sonnet',?)", [new_general_prompt]).first()
                            if completion_row[0]:
                                st.session_state.migrated.loc[st.session_state.migrated['INDEX'] == index, 'COMPLETION'] = completion_row[0]
                                process_prompt_response(st.session_state.migrated, code_path, completion_row[0], type_name, label, index, new_general_prompt, idx)
                                st.rerun()

        st.code(generate_code_skeleton(st.session_state.topo_sort))
        
        file_name = os.path.splitext(os.path.basename(st.session_state.selected_file))[0]
        export_key = "export_as_select_general"
        export_migrated_options(migrated, file_name, export_key)

    # Show sub_graphs results
    if len(sub_graphs) > 0:
        generate_sub_graphs(st.session_state.node_dict, st.session_state.subgraphs_topo, sub_graphs, code_path)

if __name__ == "__main__":
    with st.sidebar:
        sidebar()

    content()
